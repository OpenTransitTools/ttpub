About Adobe inDesign and TTPUB:

1. The easiest way to explain things is to show you.  So go get a copy of Adobe inDesign (you can download a free 30 day trial) running on a desktop computer.

2. Open the 4-Column_Tempalte.indd file included in this inDesign_Example.zip file.

IMPORTANT USER NOTE:  You will eventually need to have an inDesign template for every table width (eg: number of columns / timepoints) that you produce.  Included here is a 4-column template, with two separate tables (originally for inbound and outbound directions).  So if you have timetables with 4, 5, 6 and 7 timepoints, you will need 4 different templates for the varying sized tables you will create (limitation is due to how InDesign circa 2007 imports XML...if this has changed, please let me know).  The good news is that you probably only need 20 templates max.  That said, at TriMet, the designers have created templates for each line we have, and have all their boiler plate content in the template.  When new tables need to be generated, they simply import the new schedule data xml (output from TTPUB).  (Actually, I think they have auto import set up in such a way that they unzip the raw schedule xml files from TTPUB into a folder, then open their templates, and data gets auto loaded into the template...anyway).

3. With inDesign's document 'Structure' tool (left-hand column), unfold the Root element of the document to reveal the two table elements named 'times'.  

4. Right Click on the first 'times' element.

5. Choose the 'Import XML' option.

6. In the file chooser dialog that pops up, find the file 'rt27-4xlargeTable.xml' and open it.

7. Click OK on the XML Import dialog (we want to 'Merge Content', as opposed to 'Appending Content').

8. The Table to the left should now grow in size, and have valid times table content from the XML file.

9. Repeat steps 5-8 again, replacing but instead load one of the other sample .xml files (or maybe a 4-column table you create out of TTPUB).

10. That's it.  BTW, the XML from TTPUB is marked up with a <pm></pm> tag around times (there is no <am> tag in the default TTPUB templates), which can be used by inDesign to mark up the times to distinguish them from AM times (eg: TriMet bold's PM times in our printed tables).

Final Note: the idea of TTPUB is to keep the manual touching of data to a minimum.  If you're manually changing times, footnotes, or any of the 'dynamic' content coming out of TTPUB, that should be a red flag to stop and optimize your workflow.  At TriMet, there is very little that the designers touch in the actual timetables (eg: there is only one timetable for MAX Blue light rail, where the Friday only trips are broken out into a separate mini-table...and that's the only example I can think of where the designer has to manipulate the content).

Frank Purcell
January 2010


   