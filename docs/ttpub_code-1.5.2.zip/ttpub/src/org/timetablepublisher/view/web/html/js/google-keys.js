    // GOOGLE MAPS KEYS
    
    // GOOGLE MAPS requires a key for each DOMAIN name (including port)  
    // Here are some from my (Frank Purcell's) computer at TriMet.  
    // More to be added later...
    if(document.domain=="trimet.org") 
    {
        document.write('<script src="http://maps.google.com/maps?file=api&v=2&key=ABQIAAAA3xnAknagQvUXnjob62T29hTKjzcjt5hU0Eysj1BqNuPMUTLAtxS6ScqxBzGJzm2BmOHFJJiNYaSAWQ" type="text/javascript"></'+ 'script>')
    }
    else if(document.domain=="www.trimet.org") 
    {
        document.write('<script src="http://maps.google.com/maps?file=api&v=2&key=ABQIAAAA3xnAknagQvUXnjob62T29hQhD9WdyBqSPcjZXvLhK8H8gTwWwRRwKm49qz3j_GnkCPoufzB8VYz7Xw" type="text/javascript"></'+ 'script>')
    }
    else if(document.domain=="maps5.trimet.org") 
    {
        document.write('<script src="http://maps.google.com/maps?file=api&v=2&key=ABQIAAAAUsttaR_oBs0n4zEg2gHoGhSZuWToH0rJMlEn3RQBKT-kse4X5BTdL1jDEv_UuiwNHBpfFsP8JTKKog" type="text/javascript"></'+ 'script>')
    }    
    else if(document.domain=="mrfx.users.mcs2.netarray.com") 
    {
        document.write('<script src="http://maps.google.com/maps?file=api&v=2&key=ABQIAAAAUsttaR_oBs0n4zEg2gHoGhT0QaSGUf2i6cU2hlzTtsLgQENpGhRqI4nQ0sj_018pSxyMqfxXrtHiTQ" type="text/javascript"></'+ 'script>')
    }
    else if(document.domain=="timetablepublisher.com") 
    {
        document.write('<script src="http://maps.google.com/maps?file=api&v=2&key=ABQIAAAAUsttaR_oBs0n4zEg2gHoGhR6mnycRUcEHprvCxJ7CzmiI2exzRTgugfVqA6ceDDEC2s8PcT5SeSDWw" type="text/javascript"></'+ 'script>')
    }
    else if(document.domain=="www.timetablepublisher.com")
    {
        document.write('<script src="http://maps.google.com/maps?file=api&v=2&key=ABQIAAAAUsttaR_oBs0n4zEg2gHoGhSTR4-OcNnCtEi6VRcEIGjyf2HB4hTuCgLrXzic3AVz_E03ShLDAeso-Q" type="text/javascript"></'+ 'script>')
    }
    else if(document.domain=="timetablepublisher.org")
    {
        document.write('<script src="http://maps.google.com/maps?file=api&v=2&key=ABQIAAAAUsttaR_oBs0n4zEg2gHoGhSh-EoAZ1rbWoM2TWOAQg6DX27ZghQVIdBDP3CF1UvjjdXQbUjVBo2Zrg" type="text/javascript"></'+ 'script>')
    }
    else if(document.domain=="www.timetablepublisher.org")
    {
        document.write('<script src="http://maps.google.com/maps?file=api&v=2&key=ABQIAAAAUsttaR_oBs0n4zEg2gHoGhRZzhXbfEjlnqAv4a413-oEh2cVkxRwklMMSwJeUoFRrpKYKmkW3p5wUA" type="text/javascript"></'+ 'script>')
    }
    else if(document.domain=="dev") 
    {
        document.write('<script src="http://maps.google.com/maps?file=api&v=2&key=ABQIAAAAUsttaR_oBs0n4zEg2gHoGhTGv8pFig_qdcIeIanIjQzecSm0lRRplJr7NX9XXPTcqEdz7awAj2dAHw" type="text/javascript"></'+ 'script>')
    }
    else if(document.domain=="trinet") 
    {
        document.write('<script src="http://maps.google.com/maps?file=api&v=2&key=ABQIAAAAUsttaR_oBs0n4zEg2gHoGhTCKH9U8g3We6YaYSfMZDLl3n84ZhRed2A4yUI7cMeHEvvv-ZEY2BPxTA" type="text/javascript"></'+ 'script>')
    }
    else if(document.domain=="pan") 
    {
        document.write('<script src="http://maps.google.com/maps?file=api&v=2&key=ABQIAAAAUsttaR_oBs0n4zEg2gHoGhRtvQSfNDiW3Z9It6dxhZR9Y7NoNxT4YHlOfbE9eY7xtWkfw5_J4AwnxA" type="text/javascript"></'+ 'script>')
    }
    else if(document.domain=="ares") 
    {
        document.write('<script src="http://maps.google.com/maps?file=api&v=2&key=ABQIAAAA3xnAknagQvUXnjob62T29hQfWip23DQs3A7ht8mUtRc-njHGVhQoNv0nYEHq3cBc8DqreslNHl2QrA" type="text/javascript"></'+ 'script>')
    }
    else if(document.domain=="ares.trimet.org") 
    {
        document.write('<script src="http://maps.google.com/maps?file=api&v=2&key=ABQIAAAA3xnAknagQvUXnjob62T29hQuQq2xIttuBB580DNSac34tTzmVRRTv2AcGNTOBI4ky55b2PqkBht20Q" type="text/javascript"></'+ 'script>')
    }
    else if(document.domain=="dev.trimet.org") 
    {
        document.write('<script src="http://maps.google.com/maps?file=api&v=2&key=ABQIAAAA3xnAknagQvUXnjob62T29hSnNG0AvQfQndmd8HPIW634WPeXkxScdiNcEozDQy9xUoi7GRN1QY66xA" type="text/javascript"></'+ 'script>')
    }
    else if(document.domain=="noKEYyet.trimet.org") 
    {
        document.write('<script src="http://maps.google.com/maps?file=api&v=2&key=" type="text/javascript"></'+ 'script>')
    }
    else if(document.domain=="localhost") 
    {
        document.write('<script src="http://maps.google.com/maps?file=api&v=2&key=ABQIAAAA3xnAknagQvUXnjob62T29hTwM0brOpm-All5BF6PoaKBxRWWERTfugYWjQArs32FOZvk_pvjjBEVQA" type="text/javascript"></'+ 'script>')
    } 
    else 
    {
        document.write('<script src="http://maps.google.com/maps?file=api&v=2&key=ABQIAAAA3xnAknagQvUXnjob62T29hTqSmA7bFJVL8VKvT9TzAkD4icpCxT1J-l8aCXre2K3dXVwiGGWlmWlsw" type="text/javascript"></'+ 'script>')
    }
